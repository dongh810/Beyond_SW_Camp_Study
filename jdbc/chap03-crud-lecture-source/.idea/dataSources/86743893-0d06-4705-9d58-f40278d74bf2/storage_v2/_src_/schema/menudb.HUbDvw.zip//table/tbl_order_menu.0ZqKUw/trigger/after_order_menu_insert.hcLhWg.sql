create definer = swcamp@`%` trigger after_order_menu_insert
    after insert
    on tbl_order_menu
    for each row
BEGIN
    UPDATE tbl_order
    SET total_order_price = total_order_price + NEW.order_amount * (SELECT menu_price FROM tbl_menu WHERE menu_code = NEW.menu_code)
    WHERE order_code = NEW.order_code;
END;

